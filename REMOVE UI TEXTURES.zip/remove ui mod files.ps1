#requires -Version 7.0
param(
    [string]$ListFile = "delete_list.txt",
    [string]$BaseSubdir = "textures\flatlist\ovr_stm\_win",
    [int]$Threads = 32,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$Root = [System.IO.Path]::GetFullPath((Split-Path -Parent $PSCommandPath))
$ListPath = [System.IO.Path]::GetFullPath((Join-Path $Root $ListFile))

Write-Host "Root: $Root"
Write-Host "ListPath: $ListPath"
Write-Host "Threads: $Threads"
if ($DryRun) { Write-Host "DRY RUN ENABLED" }
Write-Host "BaseSubdir (used only for basename-only lines): $BaseSubdir"
Write-Host ""

if (-not (Test-Path -LiteralPath $ListPath)) {
    throw "List file not found: $ListPath"
}

function Clean-Line([string]$raw) {
    if ($null -eq $raw) { return $null }

    $s = $raw
    $s = $s -replace "^\uFEFF", ""  # BOM
    $s = $s -replace "\r$", ""      # CR
    $s = $s.Trim()

    if (-not $s) { return $null }
    if ($s.StartsWith("#")) { return $null }

    if ($s.Length -ge 2) {
        if (($s.StartsWith('"') -and $s.EndsWith('"')) -or ($s.StartsWith("'") -and $s.EndsWith("'"))) {
            $s = $s.Substring(1, $s.Length - 2).Trim()
        }
    }

    $s = $s.Replace("/", "\")
    return $s
}

function To-RelativePath([string]$clean) {
    # If it contains any directory separator, treat as already-relative
    if ($clean.Contains("\") -or $clean.Contains("/")) {
        return $clean
    }

    # Otherwise treat as basename under BaseSubdir
    if ([string]::IsNullOrWhiteSpace($BaseSubdir)) {
        return $clean
    }

    return (Join-Path $BaseSubdir $clean)
}

function Resolve-SafePath([string]$rootDir, [string]$relPath) {
    if ([System.IO.Path]::IsPathRooted($relPath)) { return $null }

    $fullRoot = [System.IO.Path]::GetFullPath($rootDir)
    $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($fullRoot, $relPath))

    if (-not $target.StartsWith($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $null
    }

    return $target
}

$items = New-Object System.Collections.Generic.List[string]
foreach ($raw in Get-Content -LiteralPath $ListPath -Encoding UTF8) {
    $c = Clean-Line $raw
    if ($null -eq $c) { continue }
    $items.Add((To-RelativePath $c))
}

if ($items.Count -eq 0) {
    Write-Host "Nothing to do."
    return
}

# Runspace pool
$Pool = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspacePool(1, $Threads)
$Pool.Open()

$Jobs = @()

foreach ($rel in $items) {
    $ps = [PowerShell]::Create()
    $ps.RunspacePool = $Pool

    $null = $ps.AddScript({
        param($RootDir, $RelPath, $IsDry)

        function Resolve-SafePath([string]$rootDir, [string]$relPath) {
            if ([System.IO.Path]::IsPathRooted($relPath)) { return $null }
            $fullRoot = [System.IO.Path]::GetFullPath($rootDir)
            $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($fullRoot, $relPath))
            if (-not $target.StartsWith($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $null }
            return $target
        }

        $target = Resolve-SafePath $RootDir $RelPath
        if ($null -eq $target) {
            return "[SKIP] $RelPath :: invalid path"
        }

        if (-not (Test-Path -LiteralPath $target)) {
            return "[MISS] $RelPath -> $target"
        }

        if (Test-Path -LiteralPath $target -PathType Container) {
            return "[SKIP] $RelPath :: directory"
        }

        if ($IsDry) {
            return "[DRY ] $RelPath"
        }

        try {
            Remove-Item -LiteralPath $target -Force
            return "[ OK ] $RelPath"
        } catch {
            return "[FAIL] $RelPath :: $($_.Exception.Message)"
        }
    }).AddArgument($Root).AddArgument($rel).AddArgument([bool]$DryRun)

    $Jobs += [PSCustomObject]@{ Pipe = $ps; Handle = $ps.BeginInvoke() }
}

foreach ($job in $Jobs) {
    $out = $job.Pipe.EndInvoke($job.Handle)
    $out | ForEach-Object { Write-Host $_ }
    $job.Pipe.Dispose()
}

$Pool.Close()
$Pool.Dispose()

Write-Host ""
Write-Host "Done."